package com.barclayscard.customercommand.service;

/**
 * Application service interface class.
 * @author capgemini
 *
 */
public interface CommandService {
	/**
	 * command send method.
	 * @param command command
	 */
	void send(Object command);
}
