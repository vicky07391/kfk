package com.barclayscard.customer.events;

/**
 * This is the event class for updating email address of customer.
 */
public class EmailAddressUpdatedEvent extends AbstractEvent {
  private static final long serialVersionUID = 1L;

  /** Email address. */
  private String emailAddress;

  /**
   * No argument constructor.
   */
  public EmailAddressUpdatedEvent() {
  }

  /**
   * Constructor with arguments.
   * @param id
   *          identifier
   * @param emailAddress
   *          email
   */
  public EmailAddressUpdatedEvent(String id, String emailAddress) {
    super(id);
    this.emailAddress = emailAddress;
  }

  /**
   * @return the emailAddress
   */
  public String getEmailAddress() {
    return emailAddress;
  }

  /**
   * @return the emailaddress
   */
}
