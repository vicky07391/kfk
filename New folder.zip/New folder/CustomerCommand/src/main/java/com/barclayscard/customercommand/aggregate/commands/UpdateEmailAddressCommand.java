package com.barclayscard.customercommand.aggregate.commands;

import javax.validation.constraints.NotNull;

import org.axonframework.commandhandling.annotation.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotBlank;

/**
 * command class for updating email address of customer.
 */
public class UpdateEmailAddressCommand {

  /** Target Identifier of Customer Aggregate. */
  @TargetAggregateIdentifier
  private final String id;

  /** Email Address. */
  @NotNull(message = "Email Address is mandatory")
  @NotBlank
  private final String emailAddress;

  /**
   * constructor with argument.
   * @param id
   *          Target Identifier.
   * @param emailAddress
   *          Email Address.
   */
  public UpdateEmailAddressCommand(String id, String emailAddress) {
    this.id = id;
    this.emailAddress = emailAddress;
  }

  /**
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * @return the emailAddress
   */
  public String getEmailAddress() {
    return emailAddress;
  }

}
