package com.barclayscard.customercommand.validation;

import java.util.Date;

import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.NotBlank;

import com.barclayscard.customer.valueobjects.Address;


/**
 * POJO class for mapping incoming JSON request for Customer.
 *
 */
public class CreateCustomerRequest {

  /**
   * No argument constructor.
   */
  public CreateCustomerRequest() {

  }

  /** First Name of Customer. */
  @NotNull(message = "First Name is mandatory")
  @NotBlank
  private String firstName;

  /** Last Name of Customer. */
  @NotNull(message = "Last Name is mandatory")
  @NotBlank
  private String lastName;

  /** Mobile Number of Customer. */
  @NotNull(message = "MobileNumber is mandatory")
  @NotBlank
  private String mobileNumber;

  /** EMail Address of Customer. */
  @NotNull(message = "EmailAddress is mandatory")
  @NotBlank
  private String emailAddress;

  /** Address [Building name, Street Name, Pin code] of Customer. */
  @NotNull
  private Address address;

  /** Date of Birth of Customer. */
  @NotNull(message = "DOB is mandatory")
  private Date dob;

  /**
   * Argument constructor.
   * @param firstName
   *          FirstName
   * @param lastName
   *          Last Name
   * @param mobileNumber
   *          Mobile Number
   * @param emailAddress
   *          Email Address
   * @param address
   *          Address
   * @param dob
   *          Date of Birth
   */
  public CreateCustomerRequest(String firstName, String lastName, String mobileNumber, String emailAddress,
      Address address, Date dob) {
    super();
    this.firstName = firstName;
    this.lastName = lastName;
    this.mobileNumber = mobileNumber;
    this.emailAddress = emailAddress;
    this.address = address;
    this.dob = dob;
  }

  /**
   * @return the firstName
   */
  public String getFirstName() {
    return firstName;
  }

  /**
   * @param firstName
   *          the firstName to set
   */
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  /**
   * @return the lastName
   */
  public String getLastName() {
    return lastName;
  }

  /**
   * @param lastName
   *          the lastName to set
   */
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  /**
   * @return the mobileNumber
   */
  public String getMobileNumber() {
    return mobileNumber;
  }

  /**
   * @param mobileNumber
   *          the mobileNumber to set
   */
  public void setMobileNumber(String mobileNumber) {
    this.mobileNumber = mobileNumber;
  }

  /**
   * @return the emailAddress
   */
  public String getEmailAddress() {
    return emailAddress;
  }

  /**
   * @param emailAddress
   *          the emailAddress to set
   */
  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }

  /**
   * @return the address
   */
  public Address getAddress() {
    return address;
  }

  /**
   * @param address
   *          the address to set
   */
  public void setAddress(Address address) {
    this.address = address;
  }

  /**
   * @return the dob
   */
  public Date getDob() {
    return dob;
  }

  /**
   * @param dob
   *          the dob to set
   */
  public void setDob(Date dob) {
    this.dob = dob;
  }

}
