package com.barclayscard.customercommand.controller;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.axonframework.commandhandling.CommandExecutionException;
import org.axonframework.domain.DefaultIdentifierFactory;
import org.axonframework.domain.IdentifierFactory;
import org.axonframework.repository.ConcurrencyException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.barclayscard.customer.valueobjects.Address;
import com.barclayscard.customercommand.aggregate.commands.AddCustomerCommand;
import com.barclayscard.customercommand.aggregate.commands.UpdateAddressCommand;
import com.barclayscard.customercommand.aggregate.commands.UpdateEmailAddressCommand;
import com.barclayscard.customercommand.aggregate.commands.UpdateMobileNumberCommand;
import com.barclayscard.customercommand.service.CommandService;
import com.barclayscard.customercommand.validation.CreateCustomerRequest;
import com.barclayscard.customercommand.validation.EmailRequest;
import com.barclayscard.customercommand.validation.MobileNumberRequest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * This is rest controller class for handling all the customer requests.
 *
 */
@RestController
@RequestMapping("/customers")
@Api
public class CustomerRestController {

	/** Create LoggerFactory for UpdateAddressCommandHandler. */
	private static final Logger LOG = LoggerFactory.getLogger(CustomerRestController.class);

	/**
	 * Generates a unique identifier for use by Entities (generally the
	 * Aggregate Root) and Events..
	 */
	private final IdentifierFactory identifierFactory = new DefaultIdentifierFactory();
	/** Auto wired command service. */
	@Autowired
	private CommandService commandService;

/**
 * @ApiResponses : Swagger API responses with message.
 */
	@ApiResponses(value = { @ApiResponse(code = HttpServletResponse.SC_OK, message = "Successfully retrieved list"),
			@ApiResponse(code = HttpServletResponse.SC_CREATED, message = "Customer successfully created"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED,
			message = "You are not authorized to view the resource"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN,
			message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = HttpServletResponse.SC_NOT_FOUND,
			message = "The resource you were trying to reach is not found") })

	/**
	 *  This REST Api is use for accepting request for customer creation.
	 * @param customer Customer
	 * @param response HTTP Status
	 */
	@ApiOperation(value = "Add a Customer")
	@RequestMapping(value = "/addcustomer", method = RequestMethod.POST)
	public void addCustomer(@RequestBody @Valid CreateCustomerRequest customer, HttpServletResponse response) {
		String identifier = identifierFactory.generateIdentifier();
		LOG.debug("Adding customer [{}] '{}'", identifier, customer.getFirstName(),
				customer.getLastName(), customer.getMobileNumber(),
				customer.getEmailAddress(), customer.getDob());
		try {
			AddCustomerCommand command = new AddCustomerCommand(identifier, customer.getFirstName(),
					customer.getLastName(), customer.getMobileNumber(), customer.getEmailAddress(),
					customer.getAddress(), customer.getDob());

			commandService.send(command);
			LOG.info("Added Customer [{}] '{}'", identifier, customer.getFirstName(),
					customer.getLastName(),
					customer.getMobileNumber(), customer.getEmailAddress(), customer.getDob());
			response.setStatus(HttpServletResponse.SC_CREATED);
			response.setHeader("id", identifier);
			return;
		} catch (final AssertionError ae) {
			LOG.warn("Add Request failed - empty params?. [{}] '{}'", identifier,
					customer.getFirstName(), customer.getLastName(), customer.getMobileNumber(),
					customer.getEmailAddress(), customer.getDob());
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		} catch (final CommandExecutionException cex) {
			LOG.warn("Add Command FAILED with Message: {}", cex.getMessage());
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);

			if (null != cex.getCause()) {
				LOG.warn("Caused by: {} {}", cex.getCause().getClass().getName(),
						cex.getCause().getMessage());
				if (cex.getCause() instanceof ConcurrencyException) {
					LOG.warn("A duplicate customer with the same ID [{}] already exists.",
							identifierFactory.generateIdentifier());
					response.setStatus(HttpServletResponse.SC_CONFLICT);
				}
			}
		}
	}

	/**
	 * This REST API is use for accepting request for customer Address update.
	 * @param address
	 *            Address
	 * @param response
	 *            HTTP Status
	 * @param id
	 *            unique identifier
	 */
	@ApiOperation(value = "Update a Customer Address")
	@RequestMapping(value = "/changeaddress/{id}", method = RequestMethod.PUT)
	public void updateAddress(@RequestBody @Valid Address address, @PathVariable String id,
			HttpServletResponse response) {
		UpdateAddressCommand updateaddresscommand = new UpdateAddressCommand(id, address);
		try {

			commandService.send(updateaddresscommand);

			LOG.info("Updated Customer Address ", updateaddresscommand.getId(),
					updateaddresscommand.getAddress().toString());
			response.setStatus(HttpServletResponse.SC_OK);
			return;
		} catch (final AssertionError ae) {
			LOG.warn("Update Customer Address Request failed - empty params?. [{}] '{}'",
					updateaddresscommand.getId(),
					updateaddresscommand.getAddress().toString());
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		} catch (final CommandExecutionException cex) {
			LOG.warn("Update Customer LastName Command FAILED with Message: {}", cex.getMessage());
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		}
	}

	/**
	 * This REST Api is use for accepting request for customer Email address
	 * update.
	 * @param emailRequest
	 *            EmailRequest
	 * @param id
	 *            unique identifier
	 * @param response
	 *            HTTP Status
	 */
	 @ApiOperation(value = "Update a Customer EmailAddress")
	@RequestMapping(value = "/changeemailaddress/{id}", method = RequestMethod.PUT)
	public void updateEmailAddress(@RequestBody @Valid EmailRequest emailRequest, @PathVariable String id,
			HttpServletResponse response) {
		UpdateEmailAddressCommand updateemailaddresscommand = new UpdateEmailAddressCommand(id,
				emailRequest.getEmail());
		try {
			commandService.send(updateemailaddresscommand);

			LOG.info("Updated Customer EmailAddress ", updateemailaddresscommand.getId(),
					updateemailaddresscommand.getEmailAddress());
			response.setStatus(HttpServletResponse.SC_OK);
			return;
		} catch (final AssertionError ae) {
			LOG.warn("Update Customer EmailAddress Request failed - empty params?. [{}] '{}'",
					updateemailaddresscommand.getId(), updateemailaddresscommand.getEmailAddress());
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		} catch (final CommandExecutionException cex) {
			LOG.warn("Update Customer EmailAddress Command FAILED with Message: {}", cex.getMessage());
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		}
	}

	/**
	 * This REST Api is use for accepting request for customer mobile number
	 * update.
	 * @param mobileNumberRequest
	 *            MobileNumberRequest
	 * @param id
	 *            unique identifier
	 * @param response
	 *            HTTP Status
	 */
	  @ApiOperation(value = "Update a Customer MobileNumber")
	@RequestMapping(value = "/changemobilenumber/{id}", method = RequestMethod.PUT)
	public void updateMobileNumber(@RequestBody @Valid MobileNumberRequest mobileNumberRequest,
			@PathVariable String id,
			HttpServletResponse response) {
		UpdateMobileNumberCommand updatemobilecommand = new UpdateMobileNumberCommand(id,
				mobileNumberRequest.getMobileNumber());
		try {

			commandService.send(updatemobilecommand);
			LOG.info("Updated Customer MobileNo ",
					updatemobilecommand.getId(), updatemobilecommand.getMobileNumber());
			response.setStatus(HttpServletResponse.SC_OK);
			return;
		} catch (final AssertionError ae) {
			LOG.warn("Update Customer MobileNo Request failed - empty params?. [{}] '{}'",
					updatemobilecommand.getId(),
					updatemobilecommand.getMobileNumber());
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		} catch (final CommandExecutionException cex) {
			LOG.warn("Update Customer MobileNo Command FAILED with Message: {}", cex.getMessage());
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		}
	}

}
