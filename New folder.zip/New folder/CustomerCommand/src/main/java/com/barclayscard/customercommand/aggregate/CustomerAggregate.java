package com.barclayscard.customercommand.aggregate;

import java.util.Date;

import org.axonframework.commandhandling.annotation.CommandHandler;
import org.axonframework.eventsourcing.annotation.AbstractAnnotatedAggregateRoot;
import org.axonframework.eventsourcing.annotation.AggregateIdentifier;
import org.axonframework.eventsourcing.annotation.EventSourcingHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.barclayscard.customer.events.AddressUpdatedEvent;
import com.barclayscard.customer.events.CustomerAddedEvent;
import com.barclayscard.customer.events.EmailAddressUpdatedEvent;
import com.barclayscard.customer.events.MobileNumberUpdatedEvent;
import com.barclayscard.customer.valueobjects.Address;
import com.barclayscard.customercommand.aggregate.commands.AddCustomerCommand;

/**
 * CustomerAggregate is essentially a DDD AggregateRoot (from the DDD concept). In event-sourced
 * systems, Aggregates are often stored and retreived using a 'Repository'. In the simplest terms,
 * Aggregates are the sum of their applied 'Events'.
 * <p/>
 * The Repository stores the aggregate's Events in an 'Event Store'. When an Aggregate is re-loaded
 * by the repository, the Repository re-applies all the stored events to the aggregate thereby
 * re-creating the logical state of the Aggregate.
 * <p/>
 * The CustomerAggregate Aggregate can handle and react to 'Commands', and when it reacts to these
 * com.barclayscard.customercommand.commands it creates and 'applies' Events that represent the
 * logical changes to be made. These Events are also handled by the CustomerAggregate.
 * <p/>
 * Axon takes care of much of this via the CommandBus, EventBus and Repository.
 * <p/>
 * Axon delivers com.barclayscard.customercommand.commands placed on the bus to the Aggregate. Axon
 * supports the 'applying' of Events to the Aggregate, and the handling of those events by the
 * aggregate or any other configured EventHandlers.
 */

public class CustomerAggregate extends AbstractAnnotatedAggregateRoot<String> {

  private static final long serialVersionUID = 1L;
  /** Create a Logger Factory . */
  private static final Logger LOG = LoggerFactory.getLogger(CustomerAggregate.class);

  /**
   * Aggregates that are managed by Axon must have a unique identifier. Strategies similar to GUID
   * are often used. The annotation 'AggregateIdentifier' identifies the id field as such.
   */

  @AggregateIdentifier
  private String id;

  /** FirstName of Customer. */
  private String firstName;

  /** LastName of Customer. */
  private String lastName;

  /** Mobile Number of Customer. */
  private String mobileNumber;

  /** Email Address of Customer. */
  private String emailAddress;

  /** Address of Customer.*/
  private Address address;

  /** Date of Birth of Customer.*/
  private Date dob;


  /**
   * This default constructor is used by the Repository to construct a prototype CustomerAggregate.
   * Events are then used to set properties such as the CustomerAggregate's Id in order to make the
   * Aggregate reflect it's true logical state.
   */
  public CustomerAggregate() {

  }

  /**
   * This constructor is marked as a 'CommandHandler' for the AddCustomerCommand. This command can
   * be used to construct new instances of the Aggregate. If successful a new CustomerAddedEvent is
   * 'applied' to the aggregate using the Axon 'apply' method. The apply method appears to also
   * propagate the Event to any other registered 'Event Listeners', who may take further action.
   *
   * @param command AddCutsomerCommand
   */
  @CommandHandler
  public CustomerAggregate(AddCustomerCommand command) {
    LOG.info("Command: 'AddCustomerCommand' received.");
    LOG.info("Queuing up a new CustomerAddedEvent for Customerid '{}'", command.getId());
    apply(new CustomerAddedEvent(command.getId(), command.getFirstName(), command.getLastName(),
        command.getMobileNumber(), command.getEmailAddress(), command.getAddress(),
        command.getDob()));
  }

  /**
   * Update Mobile Number command.
   * @param mobileNumber Mobile Number.
   */
  public void updateMobileNumber(String mobileNumber) {
    apply(new MobileNumberUpdatedEvent(this.id, mobileNumber));
  }

  /**
   * Update Email Address command.
   * @param emailAddress Email Address.
   */
  public void updateEmailAddress(String emailAddress) {
    apply(new EmailAddressUpdatedEvent(this.id, emailAddress));
  }

  /**
   * Update Address command.
   * @param address Address.
   */
  public void updateAddress(Address address) {
    apply(new AddressUpdatedEvent(this.id, address));
  }

  /**
   * This method is marked as an EventSourcingHandler and is therefore used by the Axon framework to
   * handle events of the specified type (CustomerAddedEvent). The CustomerAddedEvent can be raised
   * either by the constructor during CustomerAggregate(AddCustomerCommand) or by the Repository
   * when 're-loading' the aggregate.
   *
   * @param event CustomerAddedEvent
   */

  @EventSourcingHandler
  public void on(CustomerAddedEvent event) {
    this.id = event.getId();
    this.firstName = event.getFirstName();
    this.emailAddress = event.getEmailAddress();
    this.dob = event.getDob();
    this.mobileNumber = event.getMobileNumber();
    this.address = event.getAddress();
    LOG.info("Applied: 'CustomerAddedEvent' [{}] '{}'", event.getId(), event.getFirstName(),
        event.getLastName(), event.getMobileNumber(), event.getEmailAddress(), event.getDob());
  }

  /**
   * This method is marked as an EventSourcingHandler and is therefore used by the Axon framework to
   * handle events of the specified type (EmailAddressUpdatedEvent).
   * @param event EmailAddressUpdatedEvent
   */
  @EventSourcingHandler
  public void on(EmailAddressUpdatedEvent event) {
    this.emailAddress = event.getEmailAddress();
  }
  /**
   * This method is marked as an EventSourcingHandler and is therefore used by the Axon framework to
   * handle events of the specified type (MobileNumberUpdatedEvent).
   * @param event MobileNumberUpdatedEvent
   */
  @EventSourcingHandler
  public void on(MobileNumberUpdatedEvent event) {
    this.mobileNumber = event.getMobileNumber();
  }
  /**
   * This method is marked as an EventSourcingHandler and is therefore used by the Axon framework to
   * handle events of the specified type (AddressUpdatedEvent).
   * @param event AddressUpdatedEvent
   */
  @EventSourcingHandler
  public void on(AddressUpdatedEvent event) {
    this.address = event.getAddress();
  }


  /**
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * @return the firstName
   */
  public String getFirstName() {
    return firstName;
  }

  /**
   * @return the lastName
   */
  public String getLastName() {
    return lastName;
  }

  /**
   * @return the mobileNumber
   */
  public String getMobileNumber() {
    return mobileNumber;
  }

  /**
   * @return the emailAddress
   */
  public String getEmailAddress() {
    return emailAddress;
  }

  /**
   * @return the address
   */
  public Address getAddress() {
    return address;
  }

  /**
   * @return the dob
   */
  public Date getDob() {
    return dob;
  }

}
