package com.barclayscard.customer.events;

import java.io.Serializable;

/**
 * . Base class for all events
 */

public abstract class AbstractEvent implements Serializable {
  private static final long serialVersionUID = 1L;

  /** Unique identifier for event. */
  private String id;

  /** Source identifier for event. */
  private String sourceIdentifier = "RABBITMQ TCP";

  /**
   * No argument constructor.
   */
  public AbstractEvent() {
  }

  /**
   * Argument Constructor.
   * @param id
   *          identifier
   */
  public AbstractEvent(String id) {
    this.id = id;
  }

  /**
   * Getter for identifier.
   * @return the id
   */
  public String getId() {
    return id;
  }

/**
 *  Getter for SourceIdentifier.
 * @return sourceIdentifier
 */
  public String getSourceIdentifier() {
	  return sourceIdentifier;
  }


}
