package com.barclayscard.customer.events;

/**
 * This is the event class for updating mobile number of customer.
 */
public class MobileNumberUpdatedEvent extends AbstractEvent {

  private static final long serialVersionUID = 1L;

  /** Mobile Number. */
  private String mobileNumber;

  /**
   * @return the mobileNumber
   */
  public String getMobileNumber() {
    return mobileNumber;
  }

  /**
   * No argument constructor.
   */
  public MobileNumberUpdatedEvent() {
  }

  /**
   * Constructor with arguments.
   * @param id
   *          identifier
   * @param mobileNumber
   *          mobile Number
   */
  public MobileNumberUpdatedEvent(String id, String mobileNumber) {
    super(id);
    this.mobileNumber = mobileNumber;
  }
}
