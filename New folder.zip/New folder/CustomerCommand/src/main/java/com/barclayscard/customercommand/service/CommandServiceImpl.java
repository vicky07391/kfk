package com.barclayscard.customercommand.service;

import org.axonframework.commandhandling.gateway.CommandGateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * command Service implementation.
 * @author capgemini
 *
 */
public class CommandServiceImpl implements CommandService {
	/**
	 * autowiring of commnadgatway.
	 */
	@Autowired
	private CommandGateway commandGateway;
	/** Create LoggerFactory for CommandServiceImpl. */
	private static final Logger LOG = LoggerFactory.getLogger(CommandServiceImpl.class);

	/**
	 * Implementation logic for command service.
	 */
	@Override
	public void send(Object command) {
		// TODO Auto-generated method stub
		if (LOG.isDebugEnabled()) {
			LOG.info("Received command: ");
		}
		// final FutureCallback callback = new FutureCallback();
		CustomerFutureCallback customerFutureCallback = new CustomerFutureCallback();
		commandGateway.send(command, customerFutureCallback);
	}

}
