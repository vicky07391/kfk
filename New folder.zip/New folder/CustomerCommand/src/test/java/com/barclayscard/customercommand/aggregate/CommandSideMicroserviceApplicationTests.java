package com.barclayscard.customercommand.aggregate;

import java.util.Date;

import org.axonframework.test.FixtureConfiguration;
import org.axonframework.test.Fixtures;
import org.junit.Before;
import org.junit.Test;

import com.barclayscard.customer.events.CustomerAddedEvent;
import com.barclayscard.customer.valueobjects.Address;
import com.barclayscard.customercommand.aggregate.commands.AddCustomerCommand;

/*import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.axonframework.test.FixtureConfiguration;
import org.axonframework.test.Fixtures;
import org.junit.Before;
import org.junit.Test;

import com.barclayscard.common.events.AbstractEvent;
import com.barclayscard.common.events.AddressUpdatedEvent;
import com.barclayscard.common.events.CustomerAddedEvent;
import com.barclayscard.common.events.EmailAddressUpdatedEvent;
import com.barclayscard.common.events.MobileNumberUpdatedEvent;
import com.barclayscard.common.valueobjects.Address;
import com.barclayscard.customercommand.aggregates.CustomerAggregate;
import com.barclayscard.customercommand.commands.AddCustomerCommand;
import com.barclayscard.customercommand.commands.UpdateAddressCommand;
import com.barclayscard.customercommand.commands.UpdateEmailAddressCommand;
import com.barclayscard.customercommand.commands.UpdateMobileNumberCommand;*/

/**
 * JUNIT Test Cases.
 */
public class CommandSideMicroserviceApplicationTests {

	/**
	 * FixtureConfiguration.
	 */
	private FixtureConfiguration<CustomerAggregate> fixture;

	/**
	 * Setup for Test cases.
	 * @throws Exception
	 *             Exception.
	 */
	@Before
	public void setUp() throws Exception {
		fixture = Fixtures.newGivenWhenThenFixture(CustomerAggregate.class);
	}

	/**
	 * test case for addcustomer.
	 * @throws Exception Exception.
	 */
	@Test
	public void testAddCustomer() throws Exception {

		Address address = new Address("Govind Apartment", "kothrud paud road", "411038");
		Date date = new Date(System.currentTimeMillis());

		fixture.given()
				.when(new AddCustomerCommand("85975", "Mayuresh", "Harsha",
						"9007865877", "xyz1@abc.com", address,
						date))
				.expectEvents(new CustomerAddedEvent("85975", "Mayuresh", "Harsha",
						"9007865877", "xyz1@abc.com",
						address, date));

	}


}