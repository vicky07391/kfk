package com.barclayscard.customercommand.aggregate;

import java.util.Date;

import org.axonframework.domain.DefaultIdentifierFactory;
import org.axonframework.domain.IdentifierFactory;
import org.axonframework.test.FixtureConfiguration;
import org.axonframework.test.Fixtures;
import org.junit.Before;
import org.junit.Test;

import com.barclayscard.customer.events.CustomerAddedEvent;
import com.barclayscard.customer.valueobjects.Address;
import com.barclayscard.customercommand.aggregate.commands.AddCustomerCommand;
/**
 *  test class for addCustomer.
 * @author Capgemini.
 *
 */
public class AddCustomerCommandHandlerTest  {
	/**
	 * fixtureConfiguration declared.
	 */
     private FixtureConfiguration<CustomerAggregate> fixture;
 	/**
 	 * identifierFactory declared for aggregate.
 	 */
	 private final IdentifierFactory identifierFactory = new DefaultIdentifierFactory();


	 /**
		 * Setup for Test cases.
		 * @throws Exception
		 *             Exception.
		 */

    @Before
    public void setUp() throws Exception {
        fixture = Fixtures.newGivenWhenThenFixture(CustomerAggregate.class);
        CustomerAggregate commandHandler = new CustomerAggregate();
        fixture.registerAnnotatedCommandHandler(commandHandler);
//        commandHandler.setRepository(fixture.getRepository());
//        commandHandler.setOrderRepository(fixture.createGenericRepository(CustomerAggregate.class));
//        fixture.registerAnnotatedCommandHandler(commandHandler);
    }

    /**
     * TestCase for AddProduct.
     * @throws Exception Exception
     */
	@Test
	public void testAddProduct() throws Exception {
		Address address = new Address("Govind Apartment", "kothrud paud road", "411038");

		Date date = new Date(System.currentTimeMillis());
		String id = identifierFactory.generateIdentifier();
		AddCustomerCommand addCustomerCommand = new AddCustomerCommand(id, "dddMayuresh", "Harsha",
				"9007865877",
				"xyz1@abc.com", address, date);

		fixture.given().when(addCustomerCommand).expectEvents(
				new CustomerAddedEvent(id, "dddMayuresh", "Harsha", "9007865877", "xyz1@abc.com",
						address, date));
	}

}
