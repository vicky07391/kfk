package com.barclayscard.customercommand.aggregate;

/*import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Date;

import javax.servlet.http.HttpServletResponse;

import org.axonframework.commandhandling.CommandExecutionException;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockHttpServletResponse;

import com.barclayscard.common.valueobjects.Address;
import com.barclayscard.customercommand.controller.CustomerRestController;
import com.barclayscard.customercommand.entity.Customer;
import com.barclayscard.customercommand.util.Asserts;*/

/**
 * 
 */
public class CustomerRestControllerParamValadityTests {

	/*CustomerRestController controller;
	MockHttpServletResponse mockHttpServletResponse;

	@Mock
	CommandGateway gateway;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		Asserts.INSTANCE.setAssertsTo(true);
		controller = new CustomerRestController();
		mockHttpServletResponse = new MockHttpServletResponse();
	}

	@Test
	public void testAddWithGoodRequestParams() {
		// Arrange
		controller.commandGateway = gateway;
		when(gateway.sendAndWait(any())).thenReturn(null);

		// Act
		controller.addCustomer(new Customer("Mayuresh", "Harsha", "9007865877", "abc@xyz.com",
				new Address("C 502", "new DP road", "Vishalnagar"), new Date()), mockHttpServletResponse);

		// Assert
		verify(gateway).sendAndWait(any());
		assertTrue(mockHttpServletResponse.getStatus() == HttpServletResponse.SC_CREATED);
	}

	@Test
	public void testFailedAddWithAssertionError() {
		// Arrange
		controller.commandGateway = gateway;

		when(gateway.sendAndWait(any())).thenThrow(AssertionError.class);

		// Act
		controller.addCustomer(new Customer("Mayuresh", "Harsha", "9007865877", "abc@xyz.com",
				new Address("C 502", "new DP road", "Vishalnagar"), new Date()), mockHttpServletResponse);

		// Assert
		verify(gateway).sendAndWait(any());
		assertTrue(mockHttpServletResponse.getStatus() == HttpServletResponse.SC_BAD_REQUEST);
	}
*/
	/*@Test
	public void testFailedAddWithCommandExecutionException() {
		// Arrange
		controller.commandGateway = gateway;
		when(gateway.sendAndWait(any())).thenThrow(CommandExecutionException.class);

		// Act
		controller.addCustomer(new Customer("Mayuresh", "Harsha", "9007865877", "abc@xyz.com",
				new Address("C 502", "new DP road", "Vishalnagar"), new Date()), null);

		// Assert
		verify(gateway).sendAndWait(any());
		assertTrue(mockHttpServletResponse.getStatus() == HttpServletResponse.SC_BAD_REQUEST);
	}*/

}
