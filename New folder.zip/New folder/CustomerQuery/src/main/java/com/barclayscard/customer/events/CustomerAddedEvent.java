package com.barclayscard.customer.events;

import java.util.Date;

import com.barclayscard.customer.valueobjects.Address;

/**
 *CustomerAddedEvent is an event class for Adding customer.
 */
public class CustomerAddedEvent extends AbstractEvent {

	private static final long serialVersionUID = 1L;
	/** First Name of customer. */
	private String firstName;
	/** Last Name of customer. */
	private String lastName;
	/** Mobile Number of customer. */
	private String mobileNumber;
	/** Email of customer. */
	private String emailAddress;
	/** Address{Building Name, Street Name, Pin code} of customer. */
	private Address address;
	/** Date of Birth of customer. */
	private Date dob;

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}

	/**
	 * @return the dob
	 */
	public Date getDob() {
		return dob;
	}
	/** No Argument Constructor. */
	public CustomerAddedEvent() {
	}
	/**
	 * Argument Constructor.
	 * @param id
	 *            identifier of customer
	 * @param firstName
	 *            First Name of customer
	 * @param lastName
	 *            Last Name of customer
	 * @param mobileNumber
	 *            Mobile Number of customer
	 * @param emailAddress
	 *            Email of customer
	 * @param address
	 *            Address{Building Name, Street Name, Pin code} of customer
	 * @param dob
	 *            Date of Birth of customer
	 */
	public CustomerAddedEvent(String id, String firstName, String lastName,
			String mobileNumber, String emailAddress,
			Address address, Date dob) {
		super(id);
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.emailAddress = emailAddress;
		this.address = address;
		this.dob = dob;
	}

}
