package com.barclayscard.customerquery.domain.customer.handler;

import org.axonframework.eventhandling.annotation.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.barclayscard.customer.events.AddressUpdatedEvent;
import com.barclayscard.customer.events.CustomerAddedEvent;
import com.barclayscard.customer.events.EmailAddressUpdatedEvent;
import com.barclayscard.customer.events.MobileNumberUpdatedEvent;

/**
 * EventLoggingHandler is act as a event logging handler.
 */
@Component
public class EventLoggingHandler {
	/** Logger initialization for EventLoggingHandler. */
	private static final Logger LOG = LoggerFactory.getLogger(EventLoggingHandler.class);
	/** For setting up the random upper limit for number used in IID generation. */
	public static final int RANDOM_UPPER_LIMIT = 1000;
	/** For automatically generation for IID . */
	private static final String IID = String.valueOf(Double.valueOf(Math.random() * RANDOM_UPPER_LIMIT).intValue());

	/**
	 * logging handler method for CustomerAddedEvent.
	 * @param event
	 *            CustomerAddedEvent
	 */
	@EventHandler
	public void handle(CustomerAddedEvent event) {
		LOG.info("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(), event.getFirstName(),
		event.getLastName(), event.getMobileNumber(), event.getEmailAddress(), event.getAddress(),
				event.getDob());
	}

	/**
	 * logging handler method for MobileNumberUpdatedEvent.
	 * @param event
	 *            MobileNumberUpdatedEvent
	 */
	@EventHandler
	public void handle(MobileNumberUpdatedEvent event) {
		LOG.debug("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(), event.getMobileNumber());
	}

	/**
	 * logging handler method for AddressUpdatedEvent.
	 * @param event
	 *            AddressUpdatedEvent
	 */
	@EventHandler
	public void handle(AddressUpdatedEvent event) {

		LOG.debug("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(), event.getAddress());
	}

	/**
	 * logging handler method for EmailAddressUpdatedEvent.
	 * @param event
	 *            EmailAddressUpdatedEvent
	 */
	@EventHandler
	public void handle(EmailAddressUpdatedEvent event) {
		LOG.debug("Instance:{} EventType:{} EventId:[{}] '{}'", IID, event.getId(), event.getEmailAddress());
	}
}
