/**
 * @author Capgemini
 *
 */
package com.barclayscard.customerquery;