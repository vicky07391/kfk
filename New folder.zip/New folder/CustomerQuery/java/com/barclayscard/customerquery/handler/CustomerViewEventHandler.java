package com.barclayscard.customerquery.handler;

import org.axonframework.eventhandling.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.barclayscard.customerquery.domain.Address;
import com.barclayscard.customerquery.domain.Customer;
import com.barclayscard.customerquery.event.AddressUpdatedEvent;
import com.barclayscard.customerquery.event.CustomerAddedEvent;
import com.barclayscard.customerquery.event.EmailAddressUpdatedEvent;
import com.barclayscard.customerquery.event.MobileNumberUpdatedEvent;
import com.barclayscard.customerquery.repository.CustomerRepository;

@Component
public class CustomerViewEventHandler {

	private static final Logger LOG = LoggerFactory.getLogger(CustomerViewEventHandler.class);

	@Autowired
	private CustomerRepository customerRepository;

	@EventHandler
	public void handle(CustomerAddedEvent event) {
		LOG.info("CustomerAddedEvent: [{}] '{}'", event.getId(), event.getFirstName());
		Customer customer = new Customer();
		Address address = new Address(event.getAddress().getBuildingName(), event.getAddress().getStreetName() , event.getAddress().getPincode());
	
		customer.setId(event.getId());
		customer.setFirstName(event.getFirstName());
		customer.setLastName(event.getLastName());
		customer.setDob(event.getDob());
		customer.setEmailAddress(event.getEmailAddress());
		customer.setMobileNumber(event.getMobileNumber());
		customer.setAddress(address);
		customerRepository.save(customer);
	}
	
	@EventHandler
	public void handle(AddressUpdatedEvent event) {
		LOG.info("AddressUpdatedEvent: [{}] '{}'", event.getId(), event.getAddress());
		Customer customer = customerRepository.findById(event.getId());
		if(customer.getId()!=null && !(customer.getAddress().equals(event.getAddress()))){
			customer.setAddress(event.getAddress());
			customerRepository.save(customer);
		}
		
	}
	
	@EventHandler
	public void handle(EmailAddressUpdatedEvent event) {
		LOG.info("EmailAddressUpdatedEvent: [{}] '{}'", event.getId(), event.getEmailAddress());
		Customer customer = customerRepository.findById(event.getId());
		if(customer.getId()!=null && !(customer.getEmailAddress().equals(event.getEmailAddress()))){
			customer.setEmailAddress(event.getEmailAddress());
			customerRepository.save(customer);
		}
		
	}

	@EventHandler
	public void handle(MobileNumberUpdatedEvent event) {
		LOG.info("MobileNumberUpdatedEvent: [{}] '{}'", event.getId(), event.getMobileNumber());
		Customer customer = customerRepository.findById(event.getId());
		if(customer.getId()!=null && !(customer.getMobileNumber().equals(event.getMobileNumber()))){
			customer.setEmailAddress(event.getMobileNumber());
			customerRepository.save(customer);
		}
		
	}

	public void setCustomerRepository(CustomerRepository customerRepository) {
		this.customerRepository = customerRepository;
	}


}