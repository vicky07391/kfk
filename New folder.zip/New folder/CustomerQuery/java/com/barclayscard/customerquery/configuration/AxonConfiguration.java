package com.barclayscard.customerquery.configuration;

import java.util.Arrays;

import javax.jms.ConnectionFactory;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.axonframework.eventsourcing.eventstore.EventStorageEngine;
import org.axonframework.mongo.eventsourcing.eventstore.DefaultMongoTemplate;
import org.axonframework.mongo.eventsourcing.eventstore.MongoEventStorageEngine;
import org.axonframework.mongo.eventsourcing.eventstore.MongoFactory;
import org.axonframework.mongo.eventsourcing.eventstore.documentperevent.DocumentPerEventStorageStrategy;
import org.axonframework.serialization.Serializer;
import org.axonframework.spring.config.AnnotationDriven;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import com.mongodb.MongoClient;
import com.mongodb.ServerAddress;

@AnnotationDriven
@ComponentScan
@Configuration
class AxonConfiguration {

	@Value("${mongodb.url}")
	private String mongoUrl;

	@Value("${mongodb.dbname}")
	private String mongoDbName;

	@Value("${mongodb.events.collection.name}")
	private String eventsCollectionName;

	@Value("${mongodb.events.snapshot.collection.name}")
	private String snapshotCollectionName;
	@Value("${spring.activemq.broker-url}") 
	private String host;
	
	@Bean
	public EventStorageEngine eventStorageEngine(Serializer serializer) {
		return new MongoEventStorageEngine(serializer, null, axonMongoTemplate(),
				new DocumentPerEventStorageStrategy());
	}

	@Bean(name = "axonMongoTemplate")
	public DefaultMongoTemplate axonMongoTemplate() {
		DefaultMongoTemplate template = new DefaultMongoTemplate(mongoClient(), mongoDbName, eventsCollectionName,
				snapshotCollectionName);

		return template;
	}

	@Bean
	ActiveMQConnectionFactory activeMQConnectionFactory(){
	//public ConnectionFactory ConnectionFactory(@Value("${spring.activemq.broker-url}") String url) {
		ActiveMQConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory();
		activeMQConnectionFactory.setBrokerURL(host);
		return activeMQConnectionFactory;
	}

	@Bean
	public MongoClient mongoClient() {
		MongoFactory mongoFactory = new MongoFactory();
		mongoFactory.setMongoAddresses(Arrays.asList(new ServerAddress(mongoUrl)));
		return mongoFactory.createMongo();
	}

}