package com.barclayscard.customerquery.configuration;

import javax.jms.ObjectMessage;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.barclayscard.customerquery.EventMessage;
@Component
public class QueueListener {
	
	@JmsListener(destination = "example-queue")
    public void onMessage(ObjectMessage eventMessage) {  
        //TextMessage message=(TextMessage)m;
		if (eventMessage instanceof EventMessage) {
			EventMessage object = ((EventMessage) eventMessage);
			}
        try{  
            //System.out.println(message.getText());  
        }catch (Exception e) {e.printStackTrace();  }  
    }  

}
